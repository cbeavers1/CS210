#include "Account.h"

double Account::Balance(double balance, double intRate, double mthlyDeposit) {
	balance += (balance + (12 * mthlyDeposit)) * (intRate/100);
	return balance;
}

double Account::InterestEarned(double balance, double origBalance) {
	double intEarned;

	intEarned = (balance - origBalance);

	return intEarned;
}